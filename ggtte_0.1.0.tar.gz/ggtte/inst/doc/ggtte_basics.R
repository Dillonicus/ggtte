## ----knitr_setup, include = FALSE, echo = FALSE-------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  warning = FALSE,
  message = FALSE,
  cache = FALSE,
  echo = TRUE,
  comment = "#>",
  fig.width = 10,
  fig.height = 10,
  out.width = '60%'
)

## ----setup, echo = FALSE------------------------------------------------------
library(dplyr)
library(data.table)
library(ggplot2)
library(survival)
library(survminer)

## -----------------------------------------------------------------------------

# copy data from survival package
df <- survival::colon

# clean up data, label factors
df <- df %>%
  mutate(
    sex = factor(sex, levels = c(0, 1), labels = c("Female", "Male")),
    differ = factor(differ, levels = c(1, 2, 3), labels = c("Well", "Moderate", "Poor")),
    node4 = factor(node4, levels = c(0, 1), labels = c("\u22644", ">4")),
    etype = factor(etype, levels = c(1, 2), labels = c("Recurrence", "Death"))
  )

# estimate overall survival curves by treatment group
fit1 <- survfit(formula = Surv(time = time, event = status) ~ rx, data = df %>% filter(etype == "Death"))

# plot the curves
plot(fit1)

## -----------------------------------------------------------------------------
# get information about survival curves at specific timepoints
summary(fit1, times = seq(0, 1500, by = 500))

## -----------------------------------------------------------------------------
ggsurvplot(
  fit = fit1,
  censor = FALSE
)

## -----------------------------------------------------------------------------
ggsurvplot(
  fit = fit1,
  censor = FALSE,
  risk.table = TRUE
)

## -----------------------------------------------------------------------------
fit2 <- survfit(Surv(time, status) ~ rx + etype, data = df)

plot(fit2)

summary(fit2, times = seq(0, 1500, by = 500))

## -----------------------------------------------------------------------------
ggsurvplot(
  fit = fit2,
  censor = FALSE,
  risk.table = TRUE
  )

## -----------------------------------------------------------------------------
ggsurvplot_facet(
  fit = fit2,
  data = df,
  facet.by = "etype",
  censor = FALSE
  )

## -----------------------------------------------------------------------------
fit_recurrence <- survfit(Surv(time, status) ~ rx, data = df %>% filter(etype == "Recurrence"))
fit_death <- survfit(Surv(time, status) ~ rx, data = df %>% filter(etype == "Death"))

plot_recurrence <- ggsurvplot(fit_recurrence, censor = FALSE, risk.table = TRUE)
plot_death <- ggsurvplot(fit_death, censor = FALSE, risk.table = TRUE)

arrange_ggsurvplots(x = list(plot_recurrence, plot_death), nrow = 1)

## -----------------------------------------------------------------------------
library(patchwork)
plot_death$plot + 
  plot_recurrence$plot + 
  plot_death$table + 
  plot_recurrence$table + 
  plot_layout(nrow = 2, ncol = 2, guides = "collect", heights = c(0.7, 0.3)) & 
  theme(legend.position = "bottom")

## -----------------------------------------------------------------------------
library(cowplot)
plot_grid(
  plot_death$plot,
  plot_recurrence$plot,
  plot_death$table,
  plot_recurrence$table,
  align = "hv", 
  axis = "lr",
  rel_heights = c(0.7, 0.3)
)

## -----------------------------------------------------------------------------
library(ggtte)

ggtte_plot <- ggplot(
  data = df %>% filter(etype == "Death"), 
  aes(x = time, status = status, colour = rx)
  ) +
  geom_km(na.rm = TRUE) + 
  geom_risktable(aes(y = rx), na.rm = TRUE) +
  labs(x = "Time (Days)", y = "Survival") 


## -----------------------------------------------------------------------------

ggtte_plot <- ggtte_plot + 
  scale_y_continuous(labels = scales::label_percent()) + # use percent labels
  scale_tte_y_discrete()

ggtte_plot

## -----------------------------------------------------------------------------
ggtte_plot %+% 
  df + # update dataset for plots
  facet_wrap(vars(etype), nrow = 1)

## -----------------------------------------------------------------------------
ggtte_plot %+% 
  df + # update dataset for plots
  facet_grid(cols = vars(etype))

## -----------------------------------------------------------------------------
ggtte_plot %+% 
  df + # update dataset for plots
  facet_grid(cols = vars(etype), rows = vars(sex))

## -----------------------------------------------------------------------------
theme_custom <- theme(
  panel.background = element_rect(fill = NA),
  panel.border = element_rect(color = "black", fill = NA),
  panel.grid.major.y = element_line(color = "grey92", linetype = "dashed"),
  strip.placement = "outside",
  strip.background = element_rect(fill = NA),
  strip.text = element_text(size = 14),
  legend.position = "bottom", legend.key = element_rect(fill = NA))

ggtte_plot %+% df +  
  facet_grid(cols = vars(etype), rows = vars(sex)) +
  theme_custom


